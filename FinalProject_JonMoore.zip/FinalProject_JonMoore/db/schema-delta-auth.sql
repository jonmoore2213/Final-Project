-- schema-delta-auth.sql
-- Run this against the SAME database that Db.java / db.properties use.
-- If your db.url points at a different schema name, change "moviestore" below.

USE moviestore;

-- 1) Add password_hash column if it doesn't exist yet
ALTER TABLE users
  ADD COLUMN password_hash VARCHAR(100) NULL;

-- 2) (Optional) Seed a demo user hash so the provided demo login still works
-- This value should match the bcrypt hash expected by your assignment, if any.
UPDATE users
  SET password_hash = '$2a$12$DkqzI8vW8XU2m8nY3cQfUeAqvK2v2v8U8i9m9r8pVQeK1bHqgQyG2'
  WHERE username = 'demo';

-- 3) Enforce that username is not null and unique (for registration)
ALTER TABLE users
  MODIFY username VARCHAR(80) NOT NULL UNIQUE;
