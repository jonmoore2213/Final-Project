/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: LogoutServlet
 * Description:
 *  Handles user logout requests by invalidating the active session and
 *  clearing all session attributes. Once complete, the user is safely
 *  redirected to the main landing page or login screen. This servlet helps
 *  ensure that protected pages cannot be accessed after logout.
 */
package com.example.movies.web;
import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="Logout", urlPatterns={"/logout"})
public class LogoutServlet extends HttpServlet{
 protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  HttpSession s=req.getSession(false); if(s!=null) s.invalidate(); resp.sendRedirect(req.getContextPath()+"/");
 }
}