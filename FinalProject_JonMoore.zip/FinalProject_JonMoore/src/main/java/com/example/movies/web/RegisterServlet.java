/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: RegisterServlet
 * Description: Handles new user registration with validation and user-friendly error messages.
 */
package com.example.movies.web;

import com.example.movies.dao.UserDao;
import com.example.movies.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Set;

@WebServlet(name = "Register", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    private final UserDao userDao = new UserDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/jsp/register.jsp")
           .forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String confirm  = req.getParameter("confirm");

        // Keep the username in the form so the user doesn't have to retype it
        req.setAttribute("formUsername", username);

        String error = null;

        // 1) Basic required-field validation
        if (isBlank(username) || isBlank(password) || isBlank(confirm)) {
            error = "All fields are required.";
        }

        // 2) Username rules
        if (error == null) {
            String trimmed = username.trim();

            if (trimmed.length() < 3) {
                error = "Username must be at least 3 characters.";
            } else if (!trimmed.matches("[A-Za-z0-9_]+")) {
                error = "Username may only contain letters, digits, and underscore.";
            } else {
                // reserved names – you can remove or change these
                Set<String> reserved = Set.of("admin", "root", "system");
                if (reserved.contains(trimmed.toLowerCase())) {
                    error = "That username is reserved. Please choose another.";
                }
            }
        }

        // 3) Password rules
        if (error == null) {
            if (password.length() < 6) {
                error = "Password must be at least 6 characters.";
            } else if (!password.equals(confirm)) {
                error = "Passwords do not match.";
            }
        }

        // 4) Check if username already exists in DB
        if (error == null) {
            if (userDao.usernameExists(username.trim())) {
                error = "That username is already in use. Please choose another.";
            }
        }

        // 5) If any validation failed, redisplay the form with the error
        if (error != null) {
            req.setAttribute("error", error);
            req.getRequestDispatcher("/WEB-INF/jsp/register.jsp")
               .forward(req, resp);
            return;
        }

        // 6) Create user and log them in
                try {
            User u = userDao.create(username.trim(), password);
            HttpSession session = req.getSession();
            session.setAttribute("username", u.getUsername());
            session.setAttribute("userId", u.getId());
            resp.sendRedirect(req.getContextPath() + "/favorites");
        } catch (RuntimeException ex) {
            ex.printStackTrace(); // still log to server output

            String dbMessage = ex.getCause() != null
                    ? ex.getCause().getMessage()
                    : ex.getMessage();

            // Friendly message for duplicate username
            if (dbMessage != null && dbMessage.toLowerCase().contains("duplicate")) {
                req.setAttribute("error",
                        "That username is already in use. Please choose another.");
            } else {
                // Show the raw DB message to help debug
                req.setAttribute("error",
                        "Database error: " + dbMessage);
            }

            req.getRequestDispatcher("/WEB-INF/jsp/register.jsp")
               .forward(req, resp);
        }

    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
