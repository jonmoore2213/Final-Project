/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: UserDao
 * Description: Handles user lookups, registration, and login verification against the users table.
 */
package com.example.movies.dao;

import com.example.movies.db.Db;
import com.example.movies.model.User;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;

/**
 * Data access object for the users table.
 *
 * Expected minimal schema:
 *   id            INT PRIMARY KEY AUTO_INCREMENT
 *   username      VARCHAR(...) UNIQUE NOT NULL
 *   password_hash VARCHAR(...)        NOT NULL
 *
 * Any additional columns are ignored.
 */
public class UserDao {

    private static final String SELECT_USER =
            "SELECT id, username, password_hash FROM users WHERE username = ?";

    /** Look up a user by username, or return null if not found. */
    public User findByUsername(String username) {
        if (username == null) return null;

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_USER)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User u = new User();
                    u.setId((int) rs.getLong("id"));
                    u.setUsername(rs.getString("username"));
                    u.setPasswordHash(rs.getString("password_hash"));
                    return u;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding user by username", e);
        }

        return null;
    }

    /** Check if a username is already taken. */
    public boolean usernameExists(String username) {
        return findByUsername(username) != null;
    }

    /**
     * Create a new user with a BCrypt-hashed password.
     * Returns the created User with its generated id.
     */
    public User create(String username, String rawPassword) {
        final String sql = "INSERT INTO users (username, password_hash) VALUES (?, ?)";
        String hashed = BCrypt.hashpw(rawPassword, BCrypt.gensalt());

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, username);
            ps.setString(2, hashed);
            ps.executeUpdate();

            User u = new User();
            u.setUsername(username);
            u.setPasswordHash(hashed);

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    u.setId((int) keys.getLong(1));
                }
            }

            return u;
        } catch (SQLException e) {
            throw new RuntimeException("Error creating user", e);
        }
    }

    /** Verify a login attempt by comparing the supplied password with the stored hash. */
    public boolean verify(String username, String rawPassword) {
        User u = findByUsername(username);
        return u != null && BCrypt.checkpw(rawPassword, u.getPasswordHash());
    }
}
