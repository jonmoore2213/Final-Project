/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: PersonDeleteServlet
 * Description:
 *  Handles deletion of person records by ID. This servlet coordinates with
 *  the DAO layer to remove entities safely while checking for referential
 *  integrity. After completion, the user is redirected back to the updated
 *  list of people to confirm the change.
 */
package com.example.movies.web;
import com.example.movies.dao.PersonDao; import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="PersonDelete", urlPatterns={"/people/delete"})
public class PersonDeleteServlet extends HttpServlet{
 private final PersonDao dao=new PersonDao();
 protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  int id=Integer.parseInt(req.getParameter("id")); dao.delete(id); resp.sendRedirect(req.getContextPath()+"/people");
 }
}