/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: AuthFilter
 * Description: Protects secured URLs by making sure a user is logged in before access.
 */
package com.example.movies.security;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * Simple authentication filter that checks for a userId attribute
 * in the HTTP session. If not present, the user is redirected to
 * the login page.
 */
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) {
        // no-op
    }

    @Override
    public void destroy() {
        // no-op
    }

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        HttpSession session = req.getSession(false);
        boolean loggedIn = session != null && session.getAttribute("userId") != null;

        if (!loggedIn) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        chain.doFilter(request, response);
    }
}
