/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: SessionHistoryFilter
 * Description: Tracks per-session browsing history such as recently viewed genres or pages.
 */
package com.example.movies.session;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Filter that tracks a small history of recently viewed genres
 * and the last-active timestamp for the current session.
 */
public class SessionHistoryFilter implements Filter {

    public static final String ATTR_RECENT_GENRES = "recentGenres";
    public static final String ATTR_LAST_ACTIVE   = "lastActive";

    @Override
    public void init(FilterConfig filterConfig) {
        // no-op
    }

    @Override
    public void destroy() {
        // no-op
    }

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpSession session = req.getSession(true);

        String genre = req.getParameter("genre");
        if (genre != null && !genre.trim().isEmpty()) {
            @SuppressWarnings("unchecked")
            Deque<String> deque = (Deque<String>) session.getAttribute(ATTR_RECENT_GENRES);
            if (deque == null) {
                deque = new ArrayDeque<>();
            }
            // Move current genre to front; keep max 5
            deque.remove(genre);
            deque.addFirst(genre);
            while (deque.size() > 5) {
                deque.removeLast();
            }
            session.setAttribute(ATTR_RECENT_GENRES, deque);
        }

        session.setAttribute(ATTR_LAST_ACTIVE, System.currentTimeMillis());

        chain.doFilter(request, response);
    }
}
