/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: SessionTracker
 * Description: Listens for session lifecycle events and keeps counts of active sessions and users.
 */
package com.example.movies.session;

import javax.servlet.*;
import javax.servlet.http.*;
import java.time.Instant;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Listener that tracks how many sessions are active and which usernames
 * are currently logged in. Values are stored on the ServletContext so they
 * can be displayed for diagnostics.
 */
public class SessionTracker implements HttpSessionListener, HttpSessionAttributeListener {

    public static final String CTX_ACTIVE_COUNT = "activeSessionCount";
    public static final String CTX_ACTIVE_USERS = "activeUsernames";

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        ServletContext ctx = se.getSession().getServletContext();
        synchronized (ctx) {
            Integer n = (Integer) ctx.getAttribute(CTX_ACTIVE_COUNT);
            ctx.setAttribute(CTX_ACTIVE_COUNT, n == null ? 1 : n + 1);
        }
        se.getSession().setAttribute("lastSeen", Instant.now().toString());
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        ServletContext ctx = se.getSession().getServletContext();
        synchronized (ctx) {
            Integer n = (Integer) ctx.getAttribute(CTX_ACTIVE_COUNT);
            if (n != null && n > 0) {
                ctx.setAttribute(CTX_ACTIVE_COUNT, n - 1);
            }
            @SuppressWarnings("unchecked")
            Set<String> users = (Set<String>) ctx.getAttribute(CTX_ACTIVE_USERS);
            if (users != null) {
                Object username = se.getSession().getAttribute("username");
                if (username instanceof String) {
                    users.remove((String) username);
                }
            }
        }
    }

    @Override
    public void attributeAdded(HttpSessionBindingEvent event) {
        track(event);
    }

    @Override
    public void attributeRemoved(HttpSessionBindingEvent event) {
        track(event);
    }

    @Override
    public void attributeReplaced(HttpSessionBindingEvent event) {
        track(event);
    }

    private void track(HttpSessionBindingEvent e) {
        if (!"username".equals(e.getName())) {
            return;
        }
        ServletContext ctx = e.getSession().getServletContext();
        synchronized (ctx) {
            @SuppressWarnings("unchecked")
            Set<String> users = (Set<String>) ctx.getAttribute(CTX_ACTIVE_USERS);
            if (users == null) {
                users = Collections.synchronizedSet(new HashSet<>());
                ctx.setAttribute(CTX_ACTIVE_USERS, users);
            }
            Object value = e.getSession().getAttribute("username");
            if (value instanceof String) {
                users.add((String) value);
            }
        }
    }
}
