/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: SessionInfoServlet
 * Description:
 *  Displays runtime session information such as session ID, creation time,
 *  last access timestamp, tracked user history, and active session/user
 *  statistics collected by the SessionTracker listener. Useful for debugging,
 *  demonstration, and verifying session behavior during application runtime.
 */

package com.example.movies.web;
import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="SessionInfo", urlPatterns={"/session-info"})
public class SessionInfoServlet extends HttpServlet {
  @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
    req.setAttribute("activeCount", req.getServletContext().getAttribute(com.example.movies.session.SessionTracker.CTX_ACTIVE_COUNT));
    req.setAttribute("activeUsers", req.getServletContext().getAttribute(com.example.movies.session.SessionTracker.CTX_ACTIVE_USERS));
    req.getRequestDispatcher("/WEB-INF/jsp/session-info.jsp").forward(req,resp);
  }
}
