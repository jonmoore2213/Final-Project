/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: PeopleServlet
 * Description:
 *  Displays lists of actors, directors, or other associated film personnel.
 *  Provides read access to the related database tables and forwards the
 *  results to the appropriate JSP view. Designed to support navigation and
 *  expansion into more detailed person-based movie information.
 */
package com.example.movies.web;
import com.example.movies.dao.PersonDao; import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="People", urlPatterns={"/people"})
public class PeopleServlet extends HttpServlet{
 private final PersonDao dao=new PersonDao();
 protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  req.setAttribute("people", dao.findAll()); req.getRequestDispatcher("/WEB-INF/jsp/people.jsp").forward(req,resp);
 }
}