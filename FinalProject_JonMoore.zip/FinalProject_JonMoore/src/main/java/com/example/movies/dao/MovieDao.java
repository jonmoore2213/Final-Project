/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: MovieDao
 * Description: Encapsulates all database access for movies, genres, and recommendations.
 */
package com.example.movies.dao;
import com.example.movies.db.Db; import com.example.movies.model.Movie;
import java.sql.*; import java.util.*;
public class MovieDao{
 public List<Movie> findAll(){ List<Movie> out=new ArrayList<>(); String sql="SELECT id,title,year,genre FROM movies ORDER BY title";
 try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql); ResultSet rs=ps.executeQuery()){ while(rs.next()){ out.add(new Movie(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4))); } } catch(SQLException e){ throw new RuntimeException(e);} return out;}
 public Set<String> listGenres(){ Set<String> g=new TreeSet<>(); String sql="SELECT DISTINCT genre FROM movies ORDER BY genre"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql); ResultSet rs=ps.executeQuery()){ while(rs.next()) g.add(rs.getString(1)); } catch(SQLException e){ throw new RuntimeException(e);} return g;}
 public List<Movie> findByGenre(String genre){ if(genre==null||genre.isEmpty()) return findAll(); List<Movie> out=new ArrayList<>(); String sql="SELECT id,title,year,genre FROM movies WHERE LOWER(genre)=LOWER(?) ORDER BY title"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){ ps.setString(1,genre); try(ResultSet rs=ps.executeQuery()){ while(rs.next()){ out.add(new Movie(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4))); } } } catch(SQLException e){ throw new RuntimeException(e);} return out;}
 public Movie findById(int id){ String sql="SELECT id,title,year,genre FROM movies WHERE id=?"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){ ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ if(rs.next()) return new Movie(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4)); } } catch(SQLException e){ throw new RuntimeException(e);} return null;}
 public List<Movie> recommendLike(Movie base,int limit){ List<Movie> out=new ArrayList<>(); String sql="SELECT id,title,year,genre FROM movies WHERE id<>? AND LOWER(genre)=LOWER(?) ORDER BY year DESC,title LIMIT ?"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){ ps.setInt(1,base.getId()); ps.setString(2,base.getGenre()); ps.setInt(3,limit); try(ResultSet rs=ps.executeQuery()){ while(rs.next()){ out.add(new Movie(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4))); } } } catch(SQLException e){ throw new RuntimeException(e);} return out;}
 public void insert(Movie m){ String sql="INSERT INTO movies(title,year,genre) VALUES(?,?,?)"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){ ps.setString(1,m.getTitle()); ps.setInt(2,m.getYear()); ps.setString(3,m.getGenre()); ps.executeUpdate(); } catch(SQLException e){ throw new RuntimeException(e);} }
 public void update(Movie m){ String sql="UPDATE movies SET title=?,year=?,genre=? WHERE id=?"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){ ps.setString(1,m.getTitle()); ps.setInt(2,m.getYear()); ps.setString(3,m.getGenre()); ps.setInt(4,m.getId()); ps.executeUpdate(); } catch(SQLException e){ throw new RuntimeException(e);} }
 public void delete(int id){ String sql="DELETE FROM movies WHERE id=?"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){ ps.setInt(1,id); ps.executeUpdate(); } catch(SQLException e){ throw new RuntimeException(e);} }
public void addMovie(String title, int year, String genre) {
    if (title == null || title.trim().isEmpty()) {
        throw new IllegalArgumentException("Title is required");
    }
    if (genre == null || genre.trim().isEmpty()) {
        throw new IllegalArgumentException("Genre is required");
    }

    String sql = "INSERT INTO movies(title, year, genre) VALUES (?, ?, ?)";
    try (java.sql.Connection c = com.example.movies.db.Db.getConnection();
         java.sql.PreparedStatement ps = c.prepareStatement(sql)) {

        ps.setString(1, title.trim());
        ps.setInt(2, year);
        ps.setString(3, genre.trim());
        ps.executeUpdate();
    } catch (java.sql.SQLException e) {
        throw new RuntimeException(e);
    }
}

}