/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: AddMovieServlet
 * Description: Displays and processes the form for adding new movies with validation.
 */
package com.example.movies.web;

import com.example.movies.dao.MovieDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "AddMovie", urlPatterns = {"/movies/add"})
public class AddMovieServlet extends HttpServlet {

    private final MovieDao movieDao = new MovieDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher("/WEB-INF/jsp/add-movie.jsp")
           .forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String title = req.getParameter("title");
        String yearStr = req.getParameter("year");
        String genre = req.getParameter("genre");

        String error = null;
        int year = 0;

        // Basic validation
        if (title == null || title.trim().isEmpty()) {
            error = "Title is required.";
        } else if (yearStr == null || yearStr.trim().isEmpty()) {
            error = "Year is required.";
        } else {
            try {
                year = Integer.parseInt(yearStr.trim());
                int currentYear = java.time.Year.now().getValue();
                if (year < 1888 || year > currentYear + 1) {
                    error = "Year must be between 1888 and " + (currentYear + 1) + ".";
                }
            } catch (NumberFormatException ex) {
                error = "Year must be a number.";
            }
        }

        if (genre == null || genre.trim().isEmpty()) {
            if (error == null) {
                error = "Genre is required.";
            } else {
                error = error + " Genre is required.";
            }
        }

        if (error != null) {
            req.setAttribute("error", error);
            req.setAttribute("formTitle", title);
            req.setAttribute("formYear", yearStr);
            req.setAttribute("formGenre", genre);

            req.getRequestDispatcher("/WEB-INF/jsp/add-movie.jsp")
               .forward(req, resp);
            return;
        }

        // If we get here, validation passed
        try {
            movieDao.addMovie(title, year, genre);
            HttpSession session = req.getSession();
            session.setAttribute("flashMessage",
                    "Movie added successfully: " + title);
            resp.sendRedirect(req.getContextPath() + "/movies");
        } catch (RuntimeException ex) {
            req.setAttribute("error", "Unable to save movie. Please try again.");
            req.setAttribute("formTitle", title);
            req.setAttribute("formYear", yearStr);
            req.setAttribute("formGenre", genre);

            req.getRequestDispatcher("/WEB-INF/jsp/add-movie.jsp")
               .forward(req, resp);
        }
    }
}

