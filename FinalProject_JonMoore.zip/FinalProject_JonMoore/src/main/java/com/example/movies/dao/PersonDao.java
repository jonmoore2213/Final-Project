package com.example.movies.dao;
import com.example.movies.db.Db; import com.example.movies.model.Person;
import java.sql.*; import java.util.*;
public class PersonDao{
 public List<Person> findAll(){ List<Person> out=new ArrayList<>(); String sql="SELECT id,name,role FROM people ORDER BY name"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql); ResultSet rs=ps.executeQuery()){ while(rs.next()){ out.add(new Person(rs.getInt(1),rs.getString(2),rs.getString(3))); } } catch(SQLException e){ throw new RuntimeException(e);} return out;}
 public void insert(Person p){ String sql="INSERT INTO people(name,role) VALUES(?,?)"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){ ps.setString(1,p.getName()); ps.setString(2,p.getRole()); ps.executeUpdate(); } catch(SQLException e){ throw new RuntimeException(e);} }
 public void delete(int id){ String sql="DELETE FROM people WHERE id=?"; try(Connection c=Db.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){ ps.setInt(1,id); ps.executeUpdate(); } catch(SQLException e){ throw new RuntimeException(e);} }
}