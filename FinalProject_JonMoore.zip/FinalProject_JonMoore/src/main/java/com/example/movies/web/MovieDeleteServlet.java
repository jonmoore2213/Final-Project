/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: MovieDeleteServlet
 * Description:
 *  Accepts delete requests for movies by their ID. This servlet validates
 *  the request, ensures the user has permission, delegates removal to the
 *  MovieDao, and then redirects back to the updated movie list. It supports
 *  CRUD functionality and keeps the database and UI in sync.
 */
package com.example.movies.web;
import com.example.movies.dao.MovieDao; import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="MovieDelete", urlPatterns={"/movies/delete"})
public class MovieDeleteServlet extends HttpServlet{
 private final MovieDao dao=new MovieDao();
 protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  int id=Integer.parseInt(req.getParameter("id")); dao.delete(id); resp.sendRedirect(req.getContextPath()+"/movies");
 }
}