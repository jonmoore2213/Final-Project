/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: PersonAddServlet
 * Description:
 *  Presents a form for adding a new person (actor, director, etc.) to the
 *  database. Validates submitted fields, inserts records using DAO methods,
 *  and reports errors or success messages back to the JSP. Supports system
 *  growth and richer movie metadata.
 */
package com.example.movies.web;
import com.example.movies.dao.PersonDao; import com.example.movies.model.Person; import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="PersonAdd", urlPatterns={"/people/add"})
public class PersonAddServlet extends HttpServlet{
 private final PersonDao dao=new PersonDao();
 protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  req.setCharacterEncoding("UTF-8"); String name=req.getParameter("name"); String role=req.getParameter("role"); dao.insert(new Person(0,name,role)); resp.sendRedirect(req.getContextPath()+"/people");
 }
}