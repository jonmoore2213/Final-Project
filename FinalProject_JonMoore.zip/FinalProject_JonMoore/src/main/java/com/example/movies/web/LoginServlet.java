/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: LoginServlet
 * Description: Displays the login form and authenticates users into a session.
 */
package com.example.movies.web;
import com.example.movies.dao.UserDao; import com.example.movies.model.User; import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="Login", urlPatterns={"/login"})
public class LoginServlet extends HttpServlet{
 private final UserDao userDao=new UserDao();
 protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  req.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(req,resp);
 }
 protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  String username=req.getParameter("username"); String password=req.getParameter("password");
  if(userDao.verify(username, password)){ User u=userDao.findByUsername(username); HttpSession s=req.getSession(true); s.setAttribute("userId", u.getId()); s.setAttribute("username", u.getUsername()); resp.sendRedirect(req.getContextPath()+"/favorites"); }
  else { req.setAttribute("error","Invalid username or password"); req.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(req,resp); }
 }
}