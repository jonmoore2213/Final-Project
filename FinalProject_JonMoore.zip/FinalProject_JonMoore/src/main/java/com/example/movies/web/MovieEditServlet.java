/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: MovieEditServlet
 * Description:
 *  Loads an existing movie record and displays it in an editable form.
 *  Handles form submissions to update movie details such as title, genre,
 *  and release year. All updates are processed through the DAO layer to
 *  maintain proper validation and database consistency.
 */
package com.example.movies.web;
import com.example.movies.dao.MovieDao; import com.example.movies.model.Movie; import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="MovieEdit", urlPatterns={"/movies/edit"})
public class MovieEditServlet extends HttpServlet{
 private final MovieDao dao=new MovieDao();
 protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  String id=req.getParameter("id");
  if(id!=null && !id.isEmpty()){ Movie m=dao.findById(Integer.parseInt(id)); req.setAttribute("movie", m); }
  req.getRequestDispatcher("/WEB-INF/jsp/movie-form.jsp").forward(req,resp);
 }
 protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  req.setCharacterEncoding("UTF-8");
  String id=req.getParameter("id"); String title=req.getParameter("title"); int year=Integer.parseInt(req.getParameter("year")); String genre=req.getParameter("genre");
  Movie m=new Movie(); m.setTitle(title); m.setYear(year); m.setGenre(genre);
  if(id==null || id.isEmpty()){ dao.insert(m);} else { m.setId(Integer.parseInt(id)); dao.update(m); }
  resp.sendRedirect(req.getContextPath()+"/movies");
 }
}