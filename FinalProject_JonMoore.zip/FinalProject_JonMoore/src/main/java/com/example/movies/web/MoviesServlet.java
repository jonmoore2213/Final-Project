/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: MoviesServlet
 * Description: Handles requests for the Movies page and lists movies with optional genre filtering.
 */
package com.example.movies.web;
import com.example.movies.dao.MovieDao; import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet(name="Movies", urlPatterns={"/movies"})
public class MoviesServlet extends HttpServlet{
 private final MovieDao dao=new MovieDao();
 protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
  String genre=req.getParameter("genre");
  req.setAttribute("genres", dao.listGenres());
  req.setAttribute("movies", dao.findByGenre(genre));
  req.getRequestDispatcher("/WEB-INF/jsp/movies.jsp").forward(req,resp);
 }
}