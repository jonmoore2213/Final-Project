/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: MyRecsServlet
 * Description:
 *  Generates personalized movie recommendations for the logged-in user
 *  based on similar genres and past viewing interactions. This servlet
 *  gathers related data from MovieDao, prepares the response model, and
 *  forwards the results to the JSP view for display.
 */

package com.example.movies.web;
import com.example.movies.dao.MovieDao; import com.example.movies.model.Movie;
import javax.servlet.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.util.*;
@WebServlet(name="MyRecs", urlPatterns={"/me/recs"})
public class MyRecsServlet extends HttpServlet {
  private final MovieDao dao=new MovieDao();
  @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
    @SuppressWarnings("unchecked") Deque<String> recent=(Deque<String>) req.getSession(true).getAttribute(com.example.movies.session.SessionHistoryFilter.ATTR_RECENT_GENRES);
    List<Movie> picks=new ArrayList<>(); String top=null;
    if(recent!=null && !recent.isEmpty()){ top=recent.peekFirst(); picks=dao.findByGenre(top); if(picks.size()>6) picks=picks.subList(0,6); }
    req.setAttribute("topGenre", top); req.setAttribute("picks", picks);
    req.getRequestDispatcher("/WEB-INF/jsp/my-recs.jsp").forward(req,resp);
  }
}
