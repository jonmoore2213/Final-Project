/**
 * Final Project - Movie Storage System
 * Author: Jon Moore
 * Class: Db
 * Description: Initializes database settings and provides a helper to get MySQL connections.
 */package com.example.movies.db;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Db implements ServletContextListener {

    private static String url;
    private static String user;
    private static String pass;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            // Load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            ServletContext ctx = sce.getServletContext();

            // Read /WEB-INF/db.properties
            try (InputStream in = ctx.getResourceAsStream("/WEB-INF/db.properties")) {
                if (in == null) {
                    throw new IllegalStateException("db.properties not found in /WEB-INF");
                }

                Properties p = new Properties();
                p.load(in);

                url  = p.getProperty("db.url");
                user = p.getProperty("db.user");
                pass = p.getProperty("db.pass");

                if (url == null || user == null) {
                    throw new IllegalStateException("db.url or db.user missing in db.properties");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to init DB", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // nothing to clean up; we use short-lived connections
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, pass);
    }
}

