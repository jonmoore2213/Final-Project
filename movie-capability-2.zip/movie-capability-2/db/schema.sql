-- Unified schema for Capability 2C (built on Cap 1 UI)
DROP DATABASE IF EXISTS moviestore;
CREATE DATABASE moviestore CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE moviestore;

CREATE TABLE movies (
  id INT NOT NULL AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  year INT NOT NULL,
  genre VARCHAR(80) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE people (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  role ENUM('ACTOR','DIRECTOR') NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE users (
  id INT NOT NULL AUTO_INCREMENT,
  username VARCHAR(80) NOT NULL UNIQUE,
  PRIMARY KEY (id)
);

CREATE TABLE favorites (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  movie_id INT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_user_movie(user_id, movie_id),
  CONSTRAINT fk_fav_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_fav_movie FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
);

INSERT INTO users(username) VALUES ('demo');

INSERT INTO movies(title, year, genre) VALUES
('The Matrix', 1999, 'Sci-Fi'),
('Inception', 2010, 'Sci-Fi'),
('The Dark Knight', 2008, 'Action'),
('La La Land', 2016, 'Musical');

INSERT INTO people(name, role) VALUES
('Keanu Reeves', 'ACTOR'),
('Christopher Nolan', 'DIRECTOR');
