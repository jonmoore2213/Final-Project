package com.example.movies.web;

import com.example.movies.dao.PersonDao;
import com.example.movies.model.Person;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name="PersonAdd", urlPatterns={"/people/add"})
public class PersonAddServlet extends HttpServlet {
    private final PersonDao dao = new PersonDao();
    @Override
    protected void doPost(HttpServletRequest req, javax.servlet.http.HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String name = req.getParameter("name");
        String role = req.getParameter("role");
        dao.insert(new Person(0, name, role));
        resp.sendRedirect(req.getContextPath() + "/people");
    }
}
