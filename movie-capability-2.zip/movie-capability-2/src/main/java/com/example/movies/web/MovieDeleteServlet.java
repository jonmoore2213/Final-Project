package com.example.movies.web;

import com.example.movies.dao.MovieDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name="MovieDelete", urlPatterns={"/movies/delete"})
public class MovieDeleteServlet extends HttpServlet {
    private final MovieDao dao = new MovieDao();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        dao.delete(id);
        resp.sendRedirect(req.getContextPath() + "/movies");
    }
}
