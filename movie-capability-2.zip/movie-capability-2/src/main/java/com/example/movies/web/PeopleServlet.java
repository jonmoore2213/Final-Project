package com.example.movies.web;

import com.example.movies.dao.PersonDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name="People", urlPatterns={"/people"})
public class PeopleServlet extends HttpServlet {
    private final com.example.movies.dao.PersonDao dao = new PersonDao();
    @Override
    protected void doGet(HttpServletRequest req, javax.servlet.http.HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("people", dao.findAll());
        req.getRequestDispatcher("/WEB-INF/jsp/people.jsp").forward(req, resp);
    }
}
