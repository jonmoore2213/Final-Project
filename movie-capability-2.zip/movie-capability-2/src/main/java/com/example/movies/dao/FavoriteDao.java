package com.example.movies.dao;

import com.example.movies.db.Db;
import com.example.movies.model.Movie;
import java.sql.*;
import java.util.*;

public class FavoriteDao {
    public void addFavorite(int userId, int movieId){
        String sql = "INSERT INTO favorites(user_id, movie_id) VALUES(?,?)";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, userId);
            ps.setInt(2, movieId);
            ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    public void removeFavorite(int userId, int movieId){
        String sql = "DELETE FROM favorites WHERE user_id=? AND movie_id=?";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, userId);
            ps.setInt(2, movieId);
            ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
    public List<Movie> listFavorites(int userId){
        String sql = "SELECT m.id, m.title, m.year, m.genre FROM favorites f JOIN movies m ON m.id=f.movie_id WHERE f.user_id=? ORDER BY m.title";
        List<Movie> out = new ArrayList<>();
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    out.add(new Movie(rs.getInt("id"), rs.getString("title"), rs.getInt("year"), rs.getString("genre")));
                }
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }
}
