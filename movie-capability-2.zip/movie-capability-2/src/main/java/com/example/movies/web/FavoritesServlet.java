package com.example.movies.web;

import com.example.movies.dao.FavoriteDao;
import com.example.movies.dao.MovieDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name="Favorites", urlPatterns={"/favorites"})
public class FavoritesServlet extends HttpServlet {
    private final FavoriteDao favDao = new FavoriteDao();
    private final MovieDao movieDao = new MovieDao();

    private int currentUserId(HttpServletRequest req){
        // Demo user id=1
        return 1;
    }

    @Override
    protected void doGet(HttpServletRequest req, javax.servlet.http.HttpServletResponse resp) throws ServletException, IOException {
        int uid = currentUserId(req);
        req.setAttribute("favorites", favDao.listFavorites(uid));
        req.setAttribute("movies", movieDao.findAll());
        req.getRequestDispatcher("/WEB-INF/jsp/favorites.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, javax.servlet.http.HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        int uid = currentUserId(req);
        String action = req.getParameter("action");
        int movieId = Integer.parseInt(req.getParameter("movieId"));
        if ("add".equals(action)) {
            favDao.addFavorite(uid, movieId);
        } else if ("remove".equals(action)) {
            favDao.removeFavorite(uid, movieId);
        }
        resp.sendRedirect(req.getContextPath() + "/favorites");
    }
}
