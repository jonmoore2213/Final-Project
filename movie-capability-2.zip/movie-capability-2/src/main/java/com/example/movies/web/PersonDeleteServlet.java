package com.example.movies.web;

import com.example.movies.dao.PersonDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name="PersonDelete", urlPatterns={"/people/delete"})
public class PersonDeleteServlet extends HttpServlet {
    private final PersonDao dao = new PersonDao();
    @Override
    protected void doPost(HttpServletRequest req, javax.servlet.http.HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        dao.delete(id);
        resp.sendRedirect(req.getContextPath() + "/people");
    }
}
