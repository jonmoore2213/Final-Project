package com.example.movies.dao;

import com.example.movies.db.Db;
import com.example.movies.model.Movie;
import java.sql.*;
import java.util.*;

public class MovieDao {
    public List<Movie> findAll() {
        List<Movie> out = new ArrayList<>();
        String sql = "SELECT id, title, year, genre FROM movies ORDER BY title";
        try (Connection c = Db.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new Movie(rs.getInt("id"), rs.getString("title"), rs.getInt("year"), rs.getString("genre")));
            }
        } catch (SQLException e) { throw new RuntimeException(e); }
        return out;
    }

    public Set<String> listGenres(){
        Set<String> genres = new TreeSet<>();
        String sql = "SELECT DISTINCT genre FROM movies ORDER BY genre";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()){
            while (rs.next()){ genres.add(rs.getString(1)); }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return genres;
    }

    public List<Movie> findByGenre(String genre){
        if (genre == null || genre.isEmpty()) return findAll();
        List<Movie> out = new ArrayList<>();
        String sql = "SELECT id, title, year, genre FROM movies WHERE LOWER(genre)=LOWER(?) ORDER BY title";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setString(1, genre);
            try (ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    out.add(new Movie(rs.getInt("id"), rs.getString("title"), rs.getInt("year"), rs.getString("genre")));
                }
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }

    public Movie findById(int id){
        String sql = "SELECT id, title, year, genre FROM movies WHERE id=?";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()){
                    return new Movie(rs.getInt("id"), rs.getString("title"), rs.getInt("year"), rs.getString("genre"));
                }
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return null;
    }

    public List<Movie> recommendLike(Movie base, int limit){
        List<Movie> out = new ArrayList<>();
        String sql = "SELECT id, title, year, genre FROM movies WHERE id<>? AND LOWER(genre)=LOWER(?) ORDER BY year DESC, title LIMIT ?";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, base.getId());
            ps.setString(2, base.getGenre());
            ps.setInt(3, limit);
            try (ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    out.add(new Movie(rs.getInt("id"), rs.getString("title"), rs.getInt("year"), rs.getString("genre")));
                }
            }
        } catch (SQLException e){ throw new RuntimeException(e); }
        return out;
    }

    public void insert(Movie m){
        String sql = "INSERT INTO movies(title, year, genre) VALUES(?,?,?)";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setString(1, m.getTitle());
            ps.setInt(2, m.getYear());
            ps.setString(3, m.getGenre());
            ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }

    public void update(Movie m){
        String sql = "UPDATE movies SET title=?, year=?, genre=? WHERE id=?";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setString(1, m.getTitle());
            ps.setInt(2, m.getYear());
            ps.setString(3, m.getGenre());
            ps.setInt(4, m.getId());
            ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }

    public void delete(int id){
        String sql = "DELETE FROM movies WHERE id=?";
        try (Connection c = Db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e){ throw new RuntimeException(e); }
    }
}
