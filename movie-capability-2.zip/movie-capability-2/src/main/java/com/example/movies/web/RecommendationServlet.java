package com.example.movies.web;

import com.example.movies.dao.MovieDao;
import com.example.movies.model.Movie;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name="Recommendation", urlPatterns={"/recommend"})
public class RecommendationServlet extends HttpServlet {
    private final MovieDao dao = new MovieDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        String genre = req.getParameter("genre");
        if (id != null) {
            try {
                int mid = Integer.parseInt(id);
                Movie base = dao.findById(mid);
                if (base != null) {
                    List<Movie> recs = dao.recommendLike(base, 5);
                    req.setAttribute("baseMovie", base);
                    req.setAttribute("recommendations", recs);
                }
            } catch (NumberFormatException ignored) {}
        } else if (genre != null) {
            req.setAttribute("genre", genre);
            req.setAttribute("recommendations", dao.findByGenre(genre));
        }
        req.getRequestDispatcher("/WEB-INF/jsp/recommendations.jsp").forward(req, resp);
    }
}
