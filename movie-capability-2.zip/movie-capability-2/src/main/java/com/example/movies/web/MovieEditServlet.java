package com.example.movies.web;

import com.example.movies.dao.MovieDao;
import com.example.movies.model.Movie;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name="MovieEdit", urlPatterns={"/movies/edit"})
public class MovieEditServlet extends HttpServlet {
    private final MovieDao dao = new MovieDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        if (id != null && !id.isEmpty()) {
            Movie m = dao.findById(Integer.parseInt(id));
            req.setAttribute("movie", m);
        }
        req.getRequestDispatcher("/WEB-INF/jsp/movie-form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String id = req.getParameter("id");
        String title = req.getParameter("title");
        int year = Integer.parseInt(req.getParameter("year"));
        String genre = req.getParameter("genre");
        Movie m = new Movie();
        m.setTitle(title); m.setYear(year); m.setGenre(genre);
        if (id == null || id.isEmpty()) {
            dao.insert(m);
        } else {
            m.setId(Integer.parseInt(id));
            dao.update(m);
        }
        resp.sendRedirect(req.getContextPath() + "/movies");
    }
}
