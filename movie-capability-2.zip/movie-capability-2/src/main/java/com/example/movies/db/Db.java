package com.example.movies.db;

import javax.servlet.*;
import java.io.*;
import java.sql.*;
import java.util.Properties;

public class Db implements ServletContextListener {
    private static String url;
    private static String user;
    private static String pass;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            ServletContext ctx = sce.getServletContext();
            String propsPath = ctx.getInitParameter("db.props");
            try (InputStream in = ctx.getResourceAsStream(propsPath)) {
                Properties p = new Properties();
                p.load(in);
                url = p.getProperty("db.url");
                user = p.getProperty("db.user");
                pass = p.getProperty("db.pass");
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to init DB", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, pass);
    }
}
